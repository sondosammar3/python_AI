import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import random
import timeit
from PyQt5.QtWidgets import *
from PyQt5 import uic
from collections import deque
random.seed(0)
np.random.seed(0)
def setup_graph():
    G = nx.Graph()
    G.add_node("A")
    G.add_node("B")
    G.add_node("C")
    G.add_node("D")
    G.add_node("E")
    G.add_node("F")
    G.add_node("G")
    G.add_node("H")
    G.add_node("I")
    G.add_node("J")
    G.add_node("K")
    G.add_node("L")
    G.add_node("M")
    G.add_node("N")
    G.add_node("O")
    G.add_node("P")
    G.add_node("Q")
    G.add_node("R")
    G.add_node("S")
    G.add_node("T")
    G.add_node("U")

    G.add_edge("S", "H")
    G.add_edge("T", "S")
    G.add_edge("U", "S")

    G.add_edge("P", "H")
    G.add_edge("Q", "P")
    G.add_edge("R", "P")

    G.add_edge("G", "H")
    G.add_edge("A", "E")
    G.add_edge("B", "E")
    G.add_edge("C", "F")
    G.add_edge("D", "F")
    G.add_edge("E", "G")
    G.add_edge("F", "G")
    G.add_edge("H", "I")
    G.add_edge("I", "J")
    G.add_edge("I", "K")
    G.add_edge("J", "L")
    G.add_edge("J", "M")
    G.add_edge("N", "K")
    G.add_edge("O", "K")
    G.add_edge("K", "I")
    return G
G = setup_graph()
pos = nx.spring_layout(G)




def bfs(G, start_node, end_node):
    queue = deque([[start_node]])
    visited = set([start_node])
    expanded = []
    while queue:
        path = queue.popleft()
        vertex = path[-1]
        
        expanded.append(vertex)

        if vertex == end_node:
           return path
        # return list(visited) 
        # return visited-set(expanded)
          
              
       
        for neighbour in G.neighbors(vertex):
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append(path + [neighbour])

    return "No path found"

#########################################################################################################################


def bidirectional_bfs(G, start_node, end_node):
    start_queue = [start_node]

    end_queue = [end_node]
    start_visited = {start_node: None}
    end_visited = {end_node: None}
    start_expanded = [] 
    end_expanded = []
    i=1
    while start_queue and end_queue:
        current_start_node = start_queue.pop(0)
        print ( current_start_node)

        #start_expanded.append(current_start_node)
        for neighbor in G[current_start_node]:
            if neighbor not in start_visited:
                start_visited[neighbor] = current_start_node
                start_queue.append(neighbor)

                print ( list (start_visited.keys()))

                if neighbor in end_visited:
                 #return list(start_visited.keys()) + list(end_visited.keys())
                   #return start_expanded + end_expanded
                   
                   print ( list (start_visited.keys()))
                   return get_shortest_path(start_visited, end_visited, neighbor)
                
        current_end_node = end_queue.pop(0)
        print ( current_end_node)
        end_expanded.append(current_end_node)
        for neighbor in G[current_end_node]:
            if neighbor not in end_visited:
                end_visited[neighbor] = current_end_node
                end_queue.append(neighbor)

                
                if neighbor in start_visited:
                    #return list(start_visited.keys()) + list(end_visited.keys())
                    #return start_expanded + end_expanded 
                    print ( list (end_visited.keys()))
                    return get_shortest_path(start_visited, end_visited, neighbor)
   

    print("No Path")
    return []



def get_shortest_path(start_visited, end_visited, shortest_path_node):
    if shortest_path_node:
        path_start = []
        current_node = shortest_path_node
        print(current_node)
        while current_node is not None:
            path_start.insert(0, current_node)
            print(path_start)
            current_node = start_visited[current_node]

        path_end = []
        current_node = shortest_path_node
        while current_node is not None:
            path_end.append(current_node)
            print(path_end)
            current_node = end_visited[current_node]

        shortest_path = path_start + path_end[1:]
        return shortest_path
    else:
        return None

class gui(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("C:/Users/Dell/Desktop/projectAI/gui.ui", self)
        self.show()
        self.pushButton.clicked.connect(self.viewgraph)
        self.pushButton_2.clicked.connect(self.close)
        self.pushButton_3.clicked.connect(self.findBiDirectionalPath)
        self.pushButton_4.clicked.connect(self.findBfsPath)

    def viewgraph(self):
        nx.draw(G, with_labels=True, node_color="red", node_size=500,
                font_color="white", font_size=15, width=2,pos=pos)
        
        plt.show()

    def close(self):
        plt.close()

    def findBfsPath(self):
        self.close()
        start_node = self.textEdit.toPlainText()
        end_node = self.textEdit_2.toPlainText()
        start_time = timeit.default_timer()
        shortest_path = bfs(G,start_node,end_node)
        end_time = timeit.default_timer()
        execution_time = (end_time - start_time) * 1_000_000  
     
        if shortest_path:
            print(f"Shortest path: {shortest_path}")
            G_highlighted = G.subgraph(shortest_path)
            redundant_nodes = set(G.nodes) - set(shortest_path)
            nx.draw_networkx_nodes(G, pos, nodelist=redundant_nodes, node_color="white", node_size=500)
            nx.draw_networkx_edges(G, pos, edge_color="white", width=1)

            
            nx.draw_networkx_nodes(G, pos, nodelist=shortest_path, node_color="red", node_size=500)
            nx.draw_networkx_edges(G_highlighted, pos,edge_color="black", width=2)
            label_pos = pos.copy()
            offset = 0.01  
            #for node in G.nodes:
              # label_pos[node] += np.array([0, offset])
            nx.draw_networkx_labels(G, label_pos, font_color="white", font_size=12)
            self.label_4.setText(f"BFS path: {shortest_path}")
            self.label_6.setText(f"Execution time: {execution_time} microseconds") # Print the execution time
        else:
            print(f"No path between {start_node} and {end_node}")
            self.label_4.setText(f"Bi-directional BFS path: Cannot be found")

   
        plt.show()


    
    def findBiDirectionalPath(self):
        self.close()
        start_node = self.textEdit.toPlainText()
        end_node = self.textEdit_2.toPlainText()
        start_time = timeit.default_timer()
        shortest_path = bidirectional_bfs(G, start_node, end_node)
        end_time = timeit.default_timer()  # End time measurement
        execution_time = (end_time - start_time) * 1_000_000  
        if shortest_path:
            print(f"Shortest path: {shortest_path}")
            G_highlighted = G.subgraph(shortest_path)
            redundant_nodes = set(G.nodes) - set(shortest_path)
            nx.draw_networkx_nodes(G, pos, nodelist=redundant_nodes, node_color="red", node_size=500)
            nx.draw_networkx_edges(G, pos, edge_color="black", width=1)

            nx.draw_networkx_nodes(G, pos, nodelist=shortest_path, node_color="BLUE", node_size=600)
            nx.draw_networkx_edges(G_highlighted, pos,edge_color="black", width=2)
            
            label_pos = pos.copy()
   
          
            nx.draw_networkx_labels(G, label_pos, font_color="white", font_size=12)
            self.label_3.setText(f"Bi-directional BFS path: {shortest_path}")
            self.label_5.setText(f"Execution time: {execution_time} microseconds")                     
        else:
            print(f"No path between {start_node} and {end_node}")
            self.label_3.setText(f"Bi-directional BFS path: Cannot be found")




        plt.show()
    


def kk():
    app = QApplication([])
    window = gui()
    app.exec_()


if __name__ == '__main__':
    kk()

#return (set(start_expanded) | set(end_expanded)) - set(start_visited.keys()) - set(end_visited.keys())